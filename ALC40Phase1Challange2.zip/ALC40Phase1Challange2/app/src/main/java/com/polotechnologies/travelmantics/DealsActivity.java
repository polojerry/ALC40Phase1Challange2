package com.polotechnologies.travelmantics;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DealsActivity extends AppCompatActivity {

    FloatingActionButton newDealFab;
    RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deals);

        newDealFab = findViewById(R.id.fab_new_deal);
        mRecyclerView = findViewById(R.id.rv_deals);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(new DealsAdapter());

        newDealFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DealsActivity.this, NewDealsActivity.class);
                startActivity(intent);
            }
        });
    }
}
