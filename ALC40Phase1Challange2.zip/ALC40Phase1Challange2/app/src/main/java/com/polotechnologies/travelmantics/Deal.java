package com.polotechnologies.travelmantics;

public class Deal {
    private String dealId;
    private String dealName;
    private String dealDescription;
    private String dealPrice;
    private String dealImageUrl;

    public Deal() {
    }

    public Deal(String dealId, String dealName, String dealDescription, String dealPrice, String dealImageUrl) {
        this.dealId = dealId;
        this.dealName = dealName;
        this.dealDescription = dealDescription;
        this.dealPrice = dealPrice;
        this.dealImageUrl = dealImageUrl;
    }

    public String getDealId() {
        return dealId;
    }

    public String getDealName() {
        return dealName;
    }

    public String getDealDescription() {
        return dealDescription;
    }

    public String getDealPrice() {
        return dealPrice;
    }

    public String getDealImageUrl() {
        return dealImageUrl;
    }
}
