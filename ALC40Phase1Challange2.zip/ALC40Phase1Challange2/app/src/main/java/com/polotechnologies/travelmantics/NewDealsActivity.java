package com.polotechnologies.travelmantics;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class NewDealsActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 100;

    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference mDatabaseReference;
    StorageReference mStorageReference;

    AppCompatImageView mImageView;
    TextInputEditText mDealName;
    TextInputEditText mDealDescription;
    TextInputEditText mDealPrice;
    MaterialButton mButtonDealSelectImage;

    Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_deals);

        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference().child("deals");
        mStorageReference = FirebaseStorage.getInstance().getReference("deals");


        mImageView = findViewById(R.id.img_deal_image);
        mDealName = findViewById(R.id.tv_location_name);
        mDealDescription = findViewById(R.id.tv_location_description);
        mDealPrice = findViewById(R.id.tv_location_price);
        mButtonDealSelectImage = findViewById(R.id.btn_select_image);

        mButtonDealSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE && resultCode == RESULT_OK){
            if(data!=null){
                selectedImageUri =data.getData();
                Picasso.get()
                        .load(selectedImageUri)
                        .into(mImageView);
            }
        }
    }

    private void selectImage() {
        Intent selectImageIntent = new Intent();
        selectImageIntent.setType("image/*");
        selectImageIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(selectImageIntent, "Select Picture"), PICK_IMAGE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.deal_menu, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_save:
                saveDeal();
                break;
            case R.id.action_delete:
                deleteDeal();
                break;
            default:
                return super.onOptionsItemSelected(item);
        }

        return super.onOptionsItemSelected(item);
    }

    private void deleteDeal() {
    }

    private void saveDeal() {

        final String dealName = mDealName.getText().toString().trim();
        final String dealDescription = mDealDescription.getText().toString().trim();
        final String dealPrice = mDealPrice.getText().toString().trim();

        mStorageReference.child("deals").putFile(selectedImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                String imageUrl = mStorageReference.getDownloadUrl().toString();

                String id = mDatabaseReference.push().getKey();
                Deal deal = new Deal(
                        id,
                        dealName,
                        dealDescription,
                        dealPrice,
                        imageUrl
                );

                mDatabaseReference.child(id).setValue(deal).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(NewDealsActivity.this, "New Deal Added", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });


    }
}
