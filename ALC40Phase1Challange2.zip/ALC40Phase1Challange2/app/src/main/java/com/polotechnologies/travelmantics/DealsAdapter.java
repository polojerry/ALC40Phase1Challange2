package com.polotechnologies.travelmantics;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class DealsAdapter extends RecyclerView.Adapter<DealsAdapter.ViewHolder> {
    private final ArrayList<Deal> mDeals = new ArrayList<>();
    public DealsAdapter() {

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference mDatabaseReference = database.getReference().child("deals");
        ChildEventListener mChildEventListener;

        mChildEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Deal deal = dataSnapshot.getValue(Deal.class);
                mDeals.add(deal);

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };

        mDatabaseReference.addChildEventListener(mChildEventListener);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_deal,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Deal deal = mDeals.get(position);

        holder.Bind(deal);

    }

    @Override
    public int getItemCount() {
        return mDeals.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        ImageView dealImage;
        AppCompatTextView dealName;
        AppCompatTextView dealDescription;
        AppCompatTextView dealPrice;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            dealImage = itemView.findViewById(R.id.img_deal);
            dealName = itemView.findViewById(R.id.tv_deal_name);
            dealDescription = itemView.findViewById(R.id.tv_deal_description);
            dealPrice = itemView.findViewById(R.id.tv_deal_price);

            itemView.setOnClickListener(this);
        }

        public void Bind(Deal deal){
            dealName.setText(deal.getDealName());
            dealDescription.setText(deal.getDealDescription());
            dealPrice.setText(deal.getDealPrice());

            Picasso.get()
                    .load(deal.getDealImageUrl())
                    .into(dealImage);
        }

        @Override
        public void onClick(View v) {

        }
    }
}
